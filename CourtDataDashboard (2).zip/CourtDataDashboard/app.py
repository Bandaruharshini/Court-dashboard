import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Database setup
db_path = 'queries.db'
def init_db():
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS queries (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            case_type TEXT,
                            case_number TEXT,
                            filing_year TEXT,
                            raw_html TEXT
                          )''')
init_db()

# Fetch Case Details
def fetch_case_details(case_type, case_number, filing_year):
    full_case_number = f"{case_type} {case_number}/{filing_year}"
    print("🔎 Searching for:", full_case_number)

    sample_cases = {
        'CS(OS) 120/2023': {
            'parties': 'Arjun Mehta vs Orion Technologies Pvt. Ltd.',
            'filing_date': '15-Mar-2023',
            'next_hearing': '12-Sep-2025',
            'latest_order_link': 'https://delhihighcourt.nic.in/latest-order.pdf',
            'abstract': 'Civil suit over software breach and injunction on source code usage.'
        },
        'WP(C) 541/2024': {
            'parties': 'Nisha Rao vs State of Delhi',
            'filing_date': '11-Jan-2024',
            'next_hearing': '19-Aug-2025',
            'latest_order_link': 'https://delhihighcourt.nic.in/order-541.pdf',
            'abstract': 'Writ petition challenging government policy on public housing allocation.'
        },
        'FAO 88/2022': {
            'parties': 'Manoj Kumar vs Life Insurance Corp.',
            'filing_date': '20-Nov-2022',
            'next_hearing': '03-Oct-2025',
            'latest_order_link': 'https://delhihighcourt.nic.in/fao88.pdf',
            'abstract': 'Appeal on insurance claim rejection post-policy maturity.'
        }
    }

    if full_case_number in sample_cases:
        data = sample_cases[full_case_number]
        raw_html = f"<html>Simulated data for {full_case_number}</html>"
        return data, raw_html
    else:
        raise ValueError(f"❌ No case found for: {full_case_number}")

# Generate PDF Summary
def generate_pdf(data, filename):
    doc = SimpleDocTemplate(filename, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph("Court Case Details", styles['Title']))
    story.append(Spacer(1, 0.2 * inch))

    story.append(Paragraph(f"<b>Parties:</b> {data['parties']}", styles['Normal']))
    story.append(Paragraph(f"<b>Filing Date:</b> {data['filing_date']}", styles['Normal']))
    story.append(Paragraph(f"<b>Next Hearing:</b> {data['next_hearing']}", styles['Normal']))
    story.append(Paragraph(f"<b>Order PDF:</b> <a href='{data['latest_order_link']}'>{data['latest_order_link']}</a>", styles['Normal']))
    story.append(Spacer(1, 0.2 * inch))
    story.append(Paragraph(f"<b>Case Abstract:</b><br/>{data['abstract']}", styles['Normal']))

    doc.build(story)

# Routes
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        case_type = request.form['case_type'].strip()
        case_number = request.form['case_number'].strip()
        filing_year = request.form['filing_year'].strip()

        try:
            data, raw_html = fetch_case_details(case_type, case_number, filing_year)

            # Log to database
            with sqlite3.connect(db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO queries (case_type, case_number, filing_year, raw_html) VALUES (?, ?, ?, ?)",
                               (case_type, case_number, filing_year, raw_html))

            # Generate PDF
            filename = f"static/{case_type}_{case_number}_{filing_year}.pdf"
            generate_pdf(data, filename)
            data['pdf_path'] = filename

            return render_template('result.html', data=data)
        except Exception as e:
            flash(str(e), 'danger')

    return render_template('index.html')

@app.route('/download/<path:filename>')
def download_file(filename):
    return send_file(filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
